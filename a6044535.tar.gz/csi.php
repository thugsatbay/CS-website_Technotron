<!DOCTYPE html> 
<html><title>CSI</title>
<head>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/masterpage.css" />
<script type="text/javascript" src="javascript/navbar.js"></script>
<script type="text/javascript" src="javascript/countdown.js"></script>
<script type="text/javascript" src="javascript/picturecycler.js"></script>
<style type="text/css">
#extra
{position:absolute;top:9999px;left:9999px;background-image:url('club/2.jpg');}
#extra1
{position:absolute;top:9999px;left:9999px;background-image:url('club/3.jpg');}
#extra2
{position:absolute;top:9999px;left:9999px;background-image:url('club/4.jpg');}
</style>
</head>
<body>
<div id="page">
<img alt="" src="masterpagephotos/csi-web.png" id="image">
<img alt="" src="masterpagephotos/dit.png" id="image1" style=" position:relaive; top:-25px;">
<div id="navbar">
<ul>
<li id="home"><a href="index.php">Home</a></li>
<li id="csi"><a href="csi.php">CSI</a></li>
<li id="apt"><a href="fest.php">Fest Events</a></li>
<li id="us"><a href="us.php">About Us</a></li>
</ul>
</div>
<br><br>
<div id="scrollimg" style="width:498px; height:377px; margin:auto;">
<img id="csiphoto" alt="" src="club/1.jpg" style="border:2px solid #000000;">
</div><br>
<p align="center" style="margin-top:0px; margin-bottom:40px;"><i style="font-size:10px; font-family:Verdana;  text-align:center;">Bring your cursor over the image to start the cycle motion; leave the image area to stop the cycle motion</i></p>
<table border=1px; cellpadding="5px" align="center" id="clock" style="color:#ffffff;  font-size:20px; text-align:center; font-family: Verdana; vertical-align:middle; margin-top:14px;">
<tr><td></td><td style="text-decoration:blink;">:</td><td></td><td style="text-decoration:blink;">:</td><td></td><td style="text-decoration:blink;">:</td><td></td></tr>
<tr style="font-style:italic; font-size:17px;"><td>Days</td><td>,</td><td>Hrs</td><td>,</td><td>Mins</td><td>,</td><td>Secs</td></tr>
<tr><td style="font-size:13px;" colspan="7">Into The Techfest</td></tr>
</table><br>
</div>
<div id="extra"></div>
<div id="extra1"></div>
<div id="extra2"></div>
</body>
</html>