<!DOCTYPE html> 
<html>
<head><title>CSI HOME</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/masterpage.css" />
<script type="text/javascript" src="javascript/navbar.js"></script>
</head>
<body>
<div id="page">
<img alt="" src="masterpagephotos/csi-web.png" id="image">
<img alt="" src="masterpagephotos/dit.png" id="image1" style=" position:relaive; top:-25px;">
<div id="navbar">
<ul>
<li id="home"><a href="index.php">Home</a></li>
<li id="csi"><a href="csi.php">CSI</a></li>
<li id="apt"><a href="fest.php">Fest Events</a></li>
<li id="us"><a href="us.php">About Us</a></li>
</ul>
</div>
<br><br>
<div align="center">
<img alt="" src="images/webhost.png">
<br>
<img alt="" src="images/web.jpg">
<br>
<img alt="" src="images/jquery.png">&nbsp;&nbsp;&nbsp;
<img alt="" src="images/facebook.png">
<img alt="" src="images/gmail.png"><span style="font-size:20px; position:relative; bottom:40px; left:40px;">csi.dit.india@gmail.com</span>
</div>
<div align="center" style="font-size:15px; font-family:Verdana;  text-align:center; width:300px; height:100px; margin:auto;">
<fieldset>
<legend>Website Created By</legend>
<ul>
<li>Gurleen Singh - CSE 3rd Year</li>
<li>Makarand Sethi - IT 3rd Year</li>
</ul>
</fieldset>
</div>
<p id="notify" align="center" style="margin-bottom:0px; margin-top:40px;"><i style="font-size:15px; font-family:Verdana;  text-align:center;">Website best viewed on Mozilla 5.0+ and IE6+. For best viewing experience please allow the complete website to load.</i></p>
</div>
</body>
</html>