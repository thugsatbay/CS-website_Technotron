$(document).ready(function()  {
	$('#ani').live('click', function() {
		$("#dtext").html("<b>Animation :</b>Can be created using any software or be hand made like a flick book. Bring your innovative idea of creation and intellectual thinking on the table with the right blend of animation.<br>Anusha Karanwal<br>Purnima ");
	}); 
	$("#bui").live('click', function() {
		$("#dtext").html("<b>Buisness :</b>Take this endeavor seriously friends for this event checks how smooth your buisness skills are. The task is to start a small enterprise, do you have what it takes to flatter the crowd with the eloquent graceful dexterity you posses!<br>Aarushi Rawat - 9557976017<br>Amarendra Pratap Singh - 9675473579<br>Gurleen Singh - 9997770277");
	});
	$("#cm").live('click', function() {
		$("#dtext").html("<b>Coding Masters :</b>The ultimate C challenge is at your doorstep. If you think you are a hotshot at programming and are a killer with functions, classes and objects. Then look no more friend for your search is over.<br>Makrand Sethi - 9760757779<br>Gurleen Singh - 9997770277" ) ;
	});
	$("#ctc").live('click', function() {
		$("#dtext").html("<b>Crack The Code :</b>Programming a Computer efficiently is a smart art and not everyone's cup of tea. How skilled you are at writing good code and finding errors in bad code ? Here is an event that checks your mettle in the arena of efficient programming.<br>Anu Gupta - 9808967771<br>Gaurav<br>Manpreet" );
	});
	$("#deb").live('click', function() {
		$("#dtext").html("<b>Debate :</b>Its hot out their already and with the the atmosphere buzz with political melodrama let's just fire it up. Fight out with your views verbally and showcase that hidden talent that you normally use to criticize the politicians for the downfall of India.<br>Aarushi Rawat - 9557976017<br>Prarabhad - 9528252813");
	});
	$("#eco").live('click', function() {
		$("#dtext").html("<b>E-Collage :</b>E-Collage gives you the oppurtunity to create collages on your computer.With unlimited resources and a theme on your beloved college its just everybody's game. Come and take a shot at it. The best part is its environment friendly , no paper wastage!<br>Tarun - 9808570548<br>Isha Bhutani - 9897630569");
	});
	$("#gam").live('click', function() {
		$("#dtext").html("<b>Gamerz :</b>Needless to say it dosen't require any introduction. All those hard core gamerz out there just sieze this oppurtunity and make the most of it.<br>Akshay Pandey - 7409712695<br>Shubham Dimri - 879124719");
	});
	$("#pp").live('click', function() {
		$("#dtext").html("<b>Paper Presentation :</b>Technical Presentation on branch wise topics. Topic suggestion will also be provided to you.<br>Isha Bhutani - 9897630569<br>Sonali");
	});
	$("#pt").live('click', function() {
		$("#dtext").html("<b>Puzzle Trap :</b>You think a apple a day keeps a doctor away is a myth. According to you it should be a puzzle a day keeps the doctor away, then friends what are you waiting for, get started there's a 2GB pen drive to be won. <u><i><b>Participation is free</b></i></u><br>Gurleen Singh - 9997770277");
	});
	$("#qb").live('click', function() {
		$("#dtext").html("<b>Quiz Bowl :</b>Its quiz time. History, Geography, Computers, Literature, Science well thats just the beginning. Are you ready to open your books of encyclopedia and answer those hardened question thrown at you.<br>Ankit Balyan - 9634306906<br>Aditi - 9557764992");
	});
	$("#tl").live('click', function() {
		$("#dtext").html("<b>Technical Lectures :</b>On Android and Linux.<br>Shubham Saini - 9045200008");
	});
	$("#wom").live('click', function() {
		$("#dtext").html("<b>Web O' Mania :</b>The calling has come to your months of practising and learning HTML, CSS & Javascript patiently. With the addition of your majestic creativity well you could be the next Mark Zuckerberg.<br>Ankita Goyal<br>Gurleen Singh - 9997770277");
	});
	$("#tec").live('click', function() {
		$("#dtext").html("<b>Welcome to the events of Technotron. To view the details of the events single click on them.<br><i><u>To read further about a particular event double click it.</u></i></b>");
	});
	$("#jw").live('click', function() {
	$("#dtext").html("<b>Junkyard War :</b>Ready to get your hands dirty on this one. Pick that junk and make something out of it, prove the world you are the ultimate geek.<br>Aditi - 9557764992");
	});
	$("#fo").live('click', function() {
    $("#dtext").html("<b>Figure Out :</b>Mathematics is challenging but no one ever brought up the fun stuff. figure out is different, just simple mathematics problem but with a twist. Each problem requires you to apply a trick. Figuring out the trick is the challenge. Well without further confusing it, its just FIGURE OUT<br>Anu Gupta - 9808967771<br>Isha Bhutani - 9897630569");
	});
});